import React, { Component } from 'react';
import './App.css';
import MuiThemeProvider from 'material-ui/styles/MuiThemeProvider';
import AppBar from 'material-ui/AppBar';
import MoreVertIcon from 'material-ui/svg-icons/navigation/more-vert';
import IconMenu from 'material-ui/IconMenu';
import IconButton from 'material-ui/IconButton';
import RaisedButton from 'material-ui/RaisedButton';
import MenuItem from 'material-ui/MenuItem';
import {
    Table,
    TableBody,
    TableHeader,
    TableHeaderColumn,
    TableRow,
    TableRowColumn,
  } from 'material-ui/Table';
import Dialog from 'material-ui/Dialog';
import FlatButton from 'material-ui/FlatButton';
import TextField from 'material-ui/TextField';

const personList = [
    {
        "first":"John",
        "last":"Doe",
        "town":"Habla",
        "year": 1979
    },
    {
        "first":"Maija",
        "last":"Muukalainen",
        "town":"Vrsok",
        "year": 1596
    },
    {
        "first":"Gregor",
        "last":"Samsa",
        "town":"Coat of Arms",
        "year": 1915
    },
    {
        "first":"Himsu",
        "last":"Hiiri",
        "town":"Penkanpohja",
        "year": 2012
    }
];

class App extends Component {
    
    constructor() {
        super();
        this.state = {
            //Actual code.
            //currentObject = current person.
            currentObject: 0,
            vika: false,
            eka: true,
            openMenu: false,
            //Own dialog opener for every EDIT button.
            open: false,
            open1: false,
            open2: false,
            open3: false,
            newInfo: "",
            firstName: "",
            lastName: "",
            firstTown: "",
            firstYear: "",

            //Table settings.
            fixedHeader: false,
            fixedFooter: false,
            stripedRows: true,
            showRowHover: false,
            selectable: false,
            multiSelectable: false,
            enableSelectAll: false,
            deselectOnClickaway: true,
            showCheckboxes: false,
        }
    }

    toNextObject = () => {
        let co = this.state.currentObject;
        if(co < personList.length - 1) {
            co++;
            if(co === personList.length - 1) {
                this.setState({
                    vika: true,
                });
            }
            else if(co !== 0) {
                this.setState({
                    eka: false,
                });
            }
        }
        this.setState({
            currentObject: co,
        });
    } 

    toPrevObject = () => {
        let co = this.state.currentObject;
        if(co - 1 >= 0) {
            co--;
            if(co === 0) {
                this.setState({
                    eka: true,
                }); 
            }
            else if(co !== personList.length - 1) {
                this.setState({
                    vika: false,
                });
            }
        }
        this.setState({
            currentObject: co,
        });
    }

    handleOpen = () => {
        this.setState({
            open: true,
        });
    }
    handleOpen1 = () => {
        this.setState({
            open1: true,
        });
    }
    handleOpen2 = () => {
        this.setState({
            open2: true,
        });
    }
    handleOpen3 = () => {
        this.setState({
            open3: true,
        });
    }

    handleCloseCancel = () => {
        this.setState({
            open: false,
            open1: false,
            open2: false,
            open3: false,
        });
        personList[this.state.currentObject].first = this.state.firstName;
        personList[this.state.currentObject].last = this.state.lastName;
        personList[this.state.currentObject].town = this.state.firstTown;
        personList[this.state.currentObject].year = this.state.firstYear;
    }

    handleClose = () => {
        this.state.firstName = personList[this.state.currentObject].first;
        this.state.lastName = personList[this.state.currentObject].last;
        this.state.firstTown = personList[this.state.currentObject].town;
        this.state.firstYear = personList[this.state.currentObject].year;
        
        this.setState({
            open: false,
            open1: false,
            open2: false,
            open3: false,
            firstName: personList[this.state.currentObject].first,
            lastName: personList[this.state.currentObject].last,
            firstTown: personList[this.state.currentObject].town,
            firstYear: personList[this.state.currentObject].year,
        });
    }
    
    handleOpenMenu = () => {
        this.setState({
          openMenu: true,
        });
    }
    handleOnRequestChange = (value) => {
        this.setState({
          openMenu: value,
        });
    }

    updateInfo = (col, v) => {
        personList[this.state.currentObject].first = col===0 ? v : personList[this.state.currentObject].first;
        personList[this.state.currentObject].last = col===1 ? v : personList[this.state.currentObject].last;
        personList[this.state.currentObject].town = col===2 ? v : personList[this.state.currentObject].town;
        personList[this.state.currentObject].year = col===3 ? v : personList[this.state.currentObject].year;
    }
    
    render() {
        const actions = [
            <FlatButton
                label="Cancel"
                primary={true}
                keyboardFocused={true}
                onClick={this.handleCloseCancel}
            />,
            <FlatButton
            label="Continue"
            primary={true}
            keyboardFocused={true}
            onClick={this.handleClose}
            />,
        ];
        return (
            <div>
                <MuiThemeProvider>
                    <AppBar
                        title="Exercise 2.2"
                        iconElementRight={
                            <IconMenu
                                iconButtonElement={<IconButton><MoreVertIcon/></IconButton>}
                            >
                            </IconMenu>
                        }
                    >
                    </AppBar>
                    {/* Next/previous buttons. */}
                    <div>                       
                        <IconMenu
                            iconButtonElement={<IconButton><MoreVertIcon /></IconButton>}
                            open={this.state.openMenu}
                            onRequestChange={this.handleOnRequestChange}
                            >
                            <MenuItem
                                primaryText="PREVIOUS"
                                onClick={this.toPrevObject}
                                disabled={this.state.eka}                                
                            />
                            <MenuItem
                                primaryText="NEXT"
                                onClick={this.toNextObject}
                                disabled={this.state.vika}
                            />
                        </IconMenu>
                        <RaisedButton 
                            label="VIEW"
                            onClick={this.handleOpenMenu}
                            open={this.state.openMenu}
                            onRequestChange={this.handleOnRequestChange}
                        />
                    </div>    
                    
                    <Table
                        height={this.state.height}
                        fixedHeader={this.state.fixedHeader}
                        fixedFooter={this.state.fixedFooter}
                        selectable={this.state.selectable}
                        multiSelectable={this.state.multiSelectable}                        
                    >
                        <TableHeader
                            displaySelectAll={this.state.showCheckboxes}
                            adjustForCheckbox={this.state.showCheckboxes}
                            enableSelectAll={this.state.enableSelectAll}
                        >
                            <TableRow>
                                <TableHeaderColumn
                                    colSpan="1" 
                                    tooltip="Super Header"
                                    style={{textAlign: 'center'}}
                                >FILE</TableHeaderColumn>
                            </TableRow>
                        </TableHeader>
                        <TableBody
                            displayRowCheckbox={this.state.showCheckboxes}
                            deselectOnClickaway={this.state.deselectOnClickaway}
                            showRowHover={this.state.showRowHover}
                            stripedRows={this.state.stripedRows}
                        >
                            <TableRow>
                                <TableRowColumn>First Name:</TableRowColumn>
                                <TableRowColumn>{personList[this.state.currentObject].first}</TableRowColumn>
                                <TableRowColumn>
                                    <RaisedButton label="Edit" onClick={this.handleOpen}>
                                        <Dialog                                   
                                            title="Editing first name"
                                            actions={actions}
                                            modal={false}
                                            open={this.state.open}
                                            onRequestClose={this.handleClose}
                                        >
                                            New first name:
                                            <TextField
                                                id="newNameField"
                                                onChange={(e,v) => {this.updateInfo(0,v);console.log("Hep");}} 
                                            />
                                        </Dialog>
                                    </RaisedButton>
                                </TableRowColumn>
                            </TableRow>

                            <TableRow>
                                <TableRowColumn>Last Name:</TableRowColumn>
                                <TableRowColumn>{personList[this.state.currentObject].last}</TableRowColumn>
                                <TableRowColumn>
                                    <RaisedButton label="Edit" onClick={this.handleOpen1}>
                                        <Dialog
                                        title="Editing last name"
                                        actions={actions}
                                        modal={false}
                                        open={this.state.open1}
                                        onRequestClose={this.handleClose}
                                    >
                                        New last name:
                                        <TextField
                                            id="newLastNameField"
                                            onChange={(e,v) => {this.updateInfo(1,v);}} 
                                        />
                                        </Dialog>
                                    </RaisedButton>
                                </TableRowColumn>
                            </TableRow>

                            <TableRow>
                                <TableRowColumn>Birth Town:</TableRowColumn>
                                <TableRowColumn>{personList[this.state.currentObject].town}</TableRowColumn>
                                <TableRowColumn>
                                    <RaisedButton label="Edit" onClick={this.handleOpen2}>
                                        <Dialog
                                            title="Editing birth town"
                                            actions={actions}
                                            modal={false}
                                            open={this.state.open2}
                                            onRequestClose={this.handleClose}
                                        >
                                            New birth town:
                                            <TextField
                                                id="newBirthTown"
                                                onChange={(e,v) => {this.updateInfo(2,v);}} 
                                            />
                                        </Dialog>
                                    </RaisedButton>
                                </TableRowColumn>
                            </TableRow>

                            <TableRow>
                                <TableRowColumn>Birth Year:</TableRowColumn>
                                <TableRowColumn>{personList[this.state.currentObject].year}</TableRowColumn>
                                <TableRowColumn>
                                    <RaisedButton label="Edit" onClick={this.handleOpen3}>
                                        <Dialog
                                            title="Editing birth year"
                                            actions={actions}
                                            modal={false}
                                            open={this.state.open3}
                                            onRequestClose={this.handleClose}
                                        >
                                            New birth town:
                                            <TextField
                                                id="newBirthYear"
                                                onChange={(e,v) => {this.updateInfo(3,v);}} 
                                            />
                                        </Dialog>
                                    </RaisedButton>
                                </TableRowColumn>                                
                            </TableRow>

                        </TableBody>
                    </Table>

                </MuiThemeProvider>
            </div>
        );
  
    }
}
export default App;
